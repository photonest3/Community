/*
 Navicat Premium Data Transfer

 Source Server         : photo1
 Source Server Type    : SQLite
 Source Server Version : 3021000
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3021000
 File Encoding         : 65001

 Date: 25/03/2024 12:36:51
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for _arts
-- ----------------------------
DROP TABLE IF EXISTS "_arts";
CREATE TABLE "_arts" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "md5sum" integer NOT NULL,
  "title1" text,
  "title2" text,
  "photos" text,
  "type" text,
  "lastmodified" integer,
  "music" text
);

-- ----------------------------
-- Table structure for _caddie
-- ----------------------------
DROP TABLE IF EXISTS "_caddie";
CREATE TABLE "_caddie" (
  "user_id" text,
  "element_id" integer NOT NULL,
  PRIMARY KEY ("element_id")
);

-- ----------------------------
-- Table structure for _categories
-- ----------------------------
DROP TABLE IF EXISTS "_categories";
CREATE TABLE "_categories" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" text,
  "comment" text,
  "dir" text,
  "rank" integer,
  "root_id" integer,
  "visible" integer,
  "representative_picture_id" integer,
  "uppercats" text,
  "commentable" text,
  "imageorder" text,
  "permalink" text,
  "lastmodified" integer,
  "addby" integer
);

-- ----------------------------
-- Table structure for _config
-- ----------------------------
DROP TABLE IF EXISTS "_config";
CREATE TABLE "_config" (
  "param" text,
  "value" text,
  "comment" text,
  PRIMARY KEY ("param"),
  CONSTRAINT "PK_CONFIG" UNIQUE ("param" ASC)
);

-- ----------------------------
-- Records of _config
-- ----------------------------
INSERT INTO "_config" VALUES ('time_zone_bias', -480, NULL);

-- ----------------------------
-- Table structure for _favorites
-- ----------------------------
DROP TABLE IF EXISTS "_favorites";
CREATE TABLE "_favorites" (
  "user_id" text,
  "image_id" integer,
  PRIMARY KEY ("image_id")
);

-- ----------------------------
-- Table structure for _history
-- ----------------------------
DROP TABLE IF EXISTS "_history";
CREATE TABLE "_history" (
  "id" integer,
  "lastmodified" integer,
  "user_id" text,
  PRIMARY KEY ("id")
);

-- ----------------------------
-- Table structure for _image_category
-- ----------------------------
DROP TABLE IF EXISTS "_image_category";
CREATE TABLE "_image_category" (
  "image_id" integer,
  "category_id" integer,
  "rank" integer,
  PRIMARY KEY ("image_id", "category_id")
);

-- ----------------------------
-- Table structure for _image_tag
-- ----------------------------
DROP TABLE IF EXISTS "_image_tag";
CREATE TABLE "_image_tag" (
  "image_id" integer,
  "tag_id" integer,
  PRIMARY KEY ("image_id", "tag_id")
);

-- ----------------------------
-- Table structure for _images
-- ----------------------------
DROP TABLE IF EXISTS "_images";
CREATE TABLE "_images" (
  "id" integer PRIMARY KEY AUTOINCREMENT,
  "file" text,
  "date_available" integer,
  "date_creation" integer,
  "name" text,
  "comment" text,
  "author" text,
  "hit" integer DEFAULT 0,
  "filesize" integer,
  "width" integer,
  "height" integer,
  "coi" text,
  "representative_ext" text,
  "date_metadata_update" integer,
  "path" text,
  "storage_category_id" integer,
  "quality" integer,
  "md5sum" integer,
  "added_by" text,
  "rotation" integer,
  "latitude" real,
  "longitude" real,
  "lastmodified" integer,
  "ext" text,
  "date_creation_day" integer,
  "ratio" real,
  "duration" integer,
  "iscoi" integer,
  "coi_w" integer,
  "coi_h" integer,
  "coi_lastmodified" integer,
  "coi_quality" integer,
  "coi_filesize" integer,
  "orientation" integer
);

-- ----------------------------
-- Table structure for _imgerr
-- ----------------------------
DROP TABLE IF EXISTS "_imgerr";
CREATE TABLE "_imgerr" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "cat_id" integer,
  "lastmodified" integer,
  "path" text,
  "md5sum" integer,
  "msg" text
);

-- ----------------------------
-- Table structure for _log_viewer
-- ----------------------------
DROP TABLE IF EXISTS "_log_viewer";
CREATE TABLE "_log_viewer" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "folder" text,
  "file" text,
  "lastmodified" integer
);

-- ----------------------------
-- Table structure for _roots
-- ----------------------------
DROP TABLE IF EXISTS "_roots";
CREATE TABLE "_roots" (
  "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
  "root_dir" TEXT,
  "root_sizes" integer
);

-- ----------------------------
-- Table structure for _tags
-- ----------------------------
DROP TABLE IF EXISTS "_tags";
CREATE TABLE "_tags" (
  "id" integer PRIMARY KEY AUTOINCREMENT,
  "name" text,
  "url_name" text,
  "lastmodified" integer
);

-- ----------------------------
-- Table structure for _upgrade
-- ----------------------------
DROP TABLE IF EXISTS "_upgrade";
CREATE TABLE "_upgrade" (
  "id" TEXT,
  "applied" INTEGER,
  "description" TEXT,
  PRIMARY KEY ("id")
);

-- ----------------------------
-- Table structure for _users
-- ----------------------------
DROP TABLE IF EXISTS "_users";
CREATE TABLE "_users" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "username" TEXT,
  "password" TEXT,
  "hint" TEXT
);

-- ----------------------------
-- Table structure for sqlite_sequence
-- ----------------------------
DROP TABLE IF EXISTS "sqlite_sequence";
CREATE TABLE "sqlite_sequence" (
  "name",
  "seq"
);

-- ----------------------------
-- Records of sqlite_sequence
-- ----------------------------
INSERT INTO "sqlite_sequence" VALUES ('_users', 0);
INSERT INTO "sqlite_sequence" VALUES ('_imgerr', 0);
INSERT INTO "sqlite_sequence" VALUES ('_images', 0);
INSERT INTO "sqlite_sequence" VALUES ('_categories', 0);

-- ----------------------------
-- Auto increment value for _categories
-- ----------------------------

-- ----------------------------
-- Indexes structure for table _categories
-- ----------------------------
CREATE INDEX "idx_categories_dir"
ON "_categories" (
  "dir" ASC
);

-- ----------------------------
-- Indexes structure for table _image_category
-- ----------------------------
CREATE INDEX "idx_image_category_categoryid"
ON "_image_category" (
  "category_id" ASC
);
CREATE INDEX "idx_image_category_imageid"
ON "_image_category" (
  "image_id" ASC
);

-- ----------------------------
-- Indexes structure for table _image_tag
-- ----------------------------
CREATE INDEX "idx_image_tag_imageid"
ON "_image_tag" (
  "image_id" ASC
);
CREATE INDEX "idx_image_tag_tagid"
ON "_image_tag" (
  "tag_id" ASC
);

-- ----------------------------
-- Auto increment value for _images
-- ----------------------------

-- ----------------------------
-- Indexes structure for table _images
-- ----------------------------
CREATE INDEX "idx_images_author"
ON "_images" (
  "author" ASC
);
CREATE INDEX "idx_images_date_creation_day"
ON "_images" (
  "date_creation_day" ASC
);
CREATE INDEX "idx_images_date_metadata_update"
ON "_images" (
  "date_metadata_update" ASC
);
CREATE INDEX "idx_images_ext"
ON "_images" (
  "ext" ASC
);
CREATE INDEX "idx_images_filesize"
ON "_images" (
  "filesize" ASC
);
CREATE INDEX "idx_images_height"
ON "_images" (
  "height" ASC
);
CREATE INDEX "idx_images_hit"
ON "_images" (
  "hit" ASC
);
CREATE INDEX "idx_images_level"
ON "_images" (
  "quality" ASC
);
CREATE INDEX "idx_images_md5"
ON "_images" (
  "md5sum" ASC
);
CREATE INDEX "idx_images_path"
ON "_images" (
  "path" ASC
);
CREATE INDEX "idx_images_ratio"
ON "_images" (
  "ratio" ASC
);
CREATE INDEX "idx_images_width"
ON "_images" (
  "width" ASC
);

-- ----------------------------
-- Auto increment value for _imgerr
-- ----------------------------

-- ----------------------------
-- Auto increment value for _users
-- ----------------------------

PRAGMA foreign_keys = true;
